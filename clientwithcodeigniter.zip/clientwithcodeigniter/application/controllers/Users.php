<?php
    defined('BASEPATH') OR EXIT ('No direct script access allowed');

    class Users extends CI_Controller{


        public function __construct(){
            parent::__construct();
            $this->load->model('UsersModel' , 'user');
        }
        
        public function getUserList(){
           $result['queryresult'] = $this->user->getAllRecord();

           $this->load->view('layout/templates/header' , $result);
           $this->load->view('layout/payrollAdmin/UserManagement', $result);
           $this->load->view('layout/templates/footer');
        }
    }


?>