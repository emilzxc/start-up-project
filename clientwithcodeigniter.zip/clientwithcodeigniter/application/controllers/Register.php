<?php
    defined('BASEPATH') OR Exit('No direct script access allowed');

    class Register extends CI_Controller{

        public function __construct(){
            parent::__construct();
            $this->load->model('UserManagementModel' , 'usermanagement');
        }

        public function password_chck($str){
            if (preg_match('#[0-9]#', $str) && preg_match('#[a-zA-Z]#', $str)) {
                return TRUE;
              }
              return FALSE;
        }

        public function doCreate(){
            $this->load->helper(array('form', 'url'));
            $this->load->library('form_validation');

            $this->form_validation->set_rules('first_name', 'First Name', 'required');
            $this->form_validation->set_rules('last_name', 'Last Name', 'required');   
            $this->form_validation->set_rules('middle_name', 'Middle Name', 'required'); 
            $this->form_validation->set_rules('password', 'Password', 'required');
            $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
            $this->form_validation->set_rules('position' , 'Position' , 'required');

            if ($this->form_validation->run() == FALSE){
                echo '<script language="javascript">';
                echo 'alert("Error happen")';  //not showing an alert box.
                echo '</script>';
            }else{
                $firstName = $this->input->post('first_name');
                $middleName = $this->input->post('middle_name');
                $lastName = $this->input->post('last_name');
                $password = $this->input->post('password');
                $email = $this->input->post('email');
                $position = $this->input->post('position');
                $status = '0';

                $this->usermanagement->setFname($firstName);
                $this->usermanagement->setLname($lastName);
                $this->usermanagement->setMname($middleName);
                $this->usermanagement->setEmail($email);
                $this->usermanagement->setPassword($password);
                $this->usermanagement->setPosition($position);
                $this->usermanagement->setStatus($status);

                $chk = $this->usermanagement->addUser();

                if ($chk == True){

                }else{

                }
            }
        }
    }

?>