<?php
    defined('BASEPATH') OR exit('No direct script access allowed');
    class Auth extends CI_Controller{

        public function Login(){
           
            $data['title'] = 'Login';

            $this->load->view('layout/templates/header' , $data);
            $this->load->view('layout/payrollAdmin/UserManagement', $data);
            $this->load->view('layout/templates/footer');
        }
    }
?>