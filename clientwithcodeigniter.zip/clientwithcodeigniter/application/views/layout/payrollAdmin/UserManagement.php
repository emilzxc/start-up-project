<!-- Table that diplay the User Information  -->
<div class="row">
    <div class="col s12 m12 l12">
      <div class="card">
        <div class="card-content black-text">
          <span class="card-title">User List</span>
          <p>List of all user in the system.</p>
            <table class="responsive-table striped hoverable s12 m12 l12">
                <thead>
                    <tr>
                        <th>Action<th>
                        <th>User ID</th>
                        <th>User Name</th>
                        <th>User Role</th>
                        <th>User Permissions</th>
                        <th>Date of Creation</th>
                        <th>Activated</th>
                        <th>Last Login</th>
                        <th>Added by</th>
                    </tr>
                </thead>

                <tbody>
                <?php foreach($queryresult as $row): ?>
                    <tr>
                        <td><i class="material-icons"><a class="waves-effect waves-light modal-trigger" href="#modaledit">mode_edit</a></i></td>
                        <td><?php echo $row->USER_ID;?></td>
                        <td><?php echo $row->L_NAME . ' ' . $row->F_NAME . ' ' . $row->M_NAME;?></td>
                        <td><?php echo $row->ROLE_DESC ?></td>
                        <td>$0.87</td>
                        <td><?php echo date('g:i a \o\n l jS F Y',strtotime($row->CRTDN_DT) ); ?></td>
                        <td><?php  if ($row->STATUS_ID == '0'){ echo 'Not Activated'; }else {echo 'Activated';} ?></td>
                        <td>$0.87</td>
                        <td>$0.87</td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
      </div>
    </div>
</div>

<!-- Floating action button to trigger the modal of adding new user. -->
<div class="fixed-action-btn">
  <a class="btn-floating btn-large red pulse modal-trigger" id="add_user" onclick="$('.tap-target').tapTarget('close')" href="#usermodal">
    <i class="large material-icons">add</i>
  </a>
</div>

<!-- FeatureDiscovery Materialize CSS  -->
<div class="tap-target" data-target="add_user">
    <div class="tap-target-content">
      <h5>Add User</h5>
      <p>In this button you can trigger a mini window that can add a new user to the system</p>
    </div>
</div>

<!-- Modal Structure For Adding user-->
<div id="usermodal" class="modal modal-fixed-footer">
    <div class="modal-content">
      <h4>Add user to the system</h4>
      <?php
        $this->load->library('form_validation');
       ?>
      <p>Adding new user information</p>
      <?php echo form_open('Register/doCreate'); ?>
        <div class="row">
                <div class="row">
                    <div class="input-field col s4">
                        <input name="last_name" type="text" class="validate" id="last_name">
                        <label for="last_name">Last Name</label>
                    </div>

                    <div class="input-field col s4">
                        <input name="first_name" type="text" class="validate" id="first_name">
                        <label for="first_name">First Name</label>
                    </div>

                    <div class="input-field col s4">
                        <input name="middle_name" type="text" class="validate" id="middle_name">
                        <label for="middle_name">Midle Name</label>
                    </div>
                </div>

                <div class="row">
                    <div class="input-field col s3">
                        <input name="email" type="email" class="validate" id="email">
                        <label for="email">Company Email</label>
                    </div>

                    <div class="input-field col s3">
                        <select name = "position" id="position">
                            <option value="0" disabled selected>Choose your option</option>
                            <option value="1">Administrator</option>
                            <option value="2">Associate</option>
                        </select>
                        <label>Payroll </label>
                    </div>

                    <div class="input-field col s3">
                        <input name="password" type="password" class="validate" id="password">
                        <label for="password">Initial Password</label>
                    </div>

                    <div class="input-field col s3">
                        <input name="passwordMatch" type="password" class="validate" id="passwordMatch">
                        <label for="passwordMatch">Confirm Password</label>
                    </div>
                </div>

                <p>Set User Permissions</p>

                <p>
                    <label>
                        <input type="checkbox" class=""/>
                        <span>Access in Recent Activity</span>
                    </label>
                </p>

                <p>
                    <label>
                        <input type="checkbox" class=""/>
                        <span>Access to Payroll Table</span>
                    </label>
                </p>

                <p>
                    <label>
                        <input type="checkbox" class=""/>
                        <span>Allow to add user</span>
                    </label>
                </p>

                <p>
                    <label>
                        <input type="checkbox" class=""/>
                        <span>Export in PDF</span>
                    </label>
                </p>

                <p>
                    <label>
                        <input type="checkbox" class=""/>
                        <span>Export in Excel</span>
                    </label>
                </p>
        </div>
    </div>       
    <div class="modal-footer">
        <button class="btn waves-effect waves-light red" type="submit" name="action">Clear
          <i class="material-icons right">clear</i>
        </button>

        <button class="btn waves-effect waves-light blue" type="submit" name="submit">Submit
          <i class="material-icons right">send</i>
        </button>
    </div>
    </form>
</div>

 <!-- Modal Structure For updating user-->
 <div id="modaledit" class="modal">
    <div class="modal-content">
      <h4>Add user to the system</h4>
      <?php
        $this->load->library('form_validation');
       ?>
      <p>Adding new user information</p>
      <?php echo form_open('Register/doCreate'); ?>
        <div class="row">
                <div class="row">
                    <div class="input-field col s4">
                        <input name="last_name" type="text" class="validate" id="last_name">
                        <label for="last_name">Last Name</label>
                    </div>

                    <div class="input-field col s4">
                        <input name="first_name" type="text" class="validate" id="first_name">
                        <label for="first_name">First Name</label>
                    </div>

                    <div class="input-field col s4">
                        <input name="middle_name" type="text" class="validate" id="middle_name">
                        <label for="middle_name">Midle Name</label>
                    </div>
                </div>

                <div class="row">
                    <div class="input-field col s3">
                        <input name="email" type="email" class="validate" id="email">
                        <label for="email">Company Email</label>
                    </div>

                    <div class="input-field col s3">
                        <select name = "position" id="position">
                            <option value="0" disabled selected>Choose your option</option>
                            <option value="1">Administrator</option>
                            <option value="2">Associate</option>
                        </select>
                        <label>Payroll </label>
                    </div>

                    <div class="input-field col s3">
                        <input name="password" type="password" class="validate" id="password">
                        <label for="password">Initial Password</label>
                    </div>

                    <div class="input-field col s3">
                        <input name="passwordMatch" type="password" class="validate" id="passwordMatch">
                        <label for="passwordMatch">Confirm Password</label>
                    </div>
                </div>

                <p>Set User Permissions</p>

                <p>
                    <label>
                        <input type="checkbox" class=""/>
                        <span>Access in Recent Activity</span>
                    </label>
                </p>

                <p>
                    <label>
                        <input type="checkbox" class=""/>
                        <span>Access to Payroll Table</span>
                    </label>
                </p>

                <p>
                    <label>
                        <input type="checkbox" class=""/>
                        <span>Allow to add user</span>
                    </label>
                </p>

                <p>
                    <label>
                        <input type="checkbox" class=""/>
                        <span>Export in PDF</span>
                    </label>
                </p>

                <p>
                    <label>
                        <input type="checkbox" class=""/>
                        <span>Export in Excel</span>
                    </label>
                </p>
        </div>
    </div>       
    <div class="modal-footer">
        <button class="btn waves-effect waves-light red" type="submit" name="action">Clear
          <i class="material-icons right">clear</i>
        </button>

        <button class="btn waves-effect waves-light blue" type="submit" name="submit">Submit
          <i class="material-icons right">send</i>
        </button>
    </div>
    </form>
  </div>