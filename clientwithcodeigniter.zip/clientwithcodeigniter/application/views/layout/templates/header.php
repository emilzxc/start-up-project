<!DOCTYPE html>
  <html>
    <head>
      <script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script> 
      <!--Import Google Icon Font-->
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <!--Import materialize.css-->
      <link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>
      <link type="text/css" rel="stylesheet" href="css/style.css"/>
      <!--Let browser know website is optimized for mobile-->
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
      <!-- Compiled and minified CSS -->
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
      <!-- Compiled and minified JavaScript -->
      <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
      <script type="text/javascript" src="js/javascript.js"></script>
    </head>

    <nav style="background-color: #2c5491">
        <div class="nav-wrapper">
        <a href="#" data-target="slide-out" class="sidenav-trigger show-on-large"><i class="material-icons">menu</i></a>
         <a href="#!" class="brand-logo" style="padding-left: 0;"><i class="material-icons"></i>Special PS Formatter</a>
          <ul class="right hide-on-med-and-down">
            <li><a href="#modal1" data-position="bottom" data-tooltip="Extract Data" class="modal-trigger btn tooltipped" style="background-color:#2c5491" ><i class="material-icons right ">file_download</i>Load Data</a></li>
            <li><a class="btn tooltipped" href="#" data-position="bottom" data-tooltip="Export as pdf" style="background-color:#2c5491" id="pdf" onclick="Export()"><i class="material-icons right">picture_as_pdf</i>Export in</a></li>
            <li><a class="btn tooltipped" href="#" data-position="bottom" data-tooltip="Import as excel" style="background-color:#2c5491"><i class="material-icons right">insert_drive_file</i>Export in</a></li>
            <li><a href="#" data-target="slide-out" class="sidenav-trigger btn"><i class="material-icons">menu</i></a></li>
        </ul>
        </div>
    </nav>

    <ul id="slide-out" class="sidenav sidenav">
        <li>
            <div class="user-view" style="background-color: #2c5491">
                <a href="#user"><img class="circle" src="Images/avatar.jpg"></a>
                 <a href="#name" class='btn-flat dropdown-trigger white-text' data-target='profile-dropdown' style="width:100%;">
                    <span class="white-text name">Juan Pedro
                      <i class="material-icons right white-text" style="padding-left:-90px;">arrow_drop_down</i>
                    </span>
                </a>
                <ul id='profile-dropdown' class='dropdown-content'>
                    <li class="white"><a href="#" class="waves-effect waves-blue"><i class="material-icons">account_box</i>My Profile</a></li>
                    <li><a href="#"><i class="material-icons">exit_to_app</i>Logout</a></li>
                </ul>
                <a href="#email"><span class="white-text email">jdandturk@gmail.com</span></a>
            </div>    
        </li>
        <li class="white"><a href="#" class="waves-effect waves-blue"><i class="material-icons">info_outline</i>Payroll Table</a></li>
        <li class="white"><a href="#" class="waves-effect waves-blue"><i class="material-icons">recent_actors</i>Recent Activity</a></li>
        <li class="white"><a href="#" class="waves-effect waves-blue"><i class="material-icons">people_outline</i>User Management</a></li>
        <li class="white"><div class="divider"></div></li>
    </ul>
    <body>
    