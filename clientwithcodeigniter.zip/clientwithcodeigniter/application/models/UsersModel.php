<?php

    defined('BASEPATH') OR EXIT ('No direct script access allowed');

    class UsersModel extends CI_Model{

        public function getAllRecord(){
        
            $this->db->select('user.* , role.ROLE_DESC , pass.CRTDN_DT , status.STATUS_ID');
            $this->db->from('tbl_userinfo as user');
            $this->db->join('tbl_password as pass' , 'user.USER_ID = pass.USER_ID');
            $this->db->join('tbl_account_status as status' , 'user.USER_ID = status.USER_ID');
            $this->db->join('tbl_user_role as userrole' , 'user.USER_ID = userrole.USER_ID');
            $this->db->join('tbl_role as role' , 'userrole.USER_ROLE = role.USER_ROLE');
            //$this->db->join('tbl_logs as logs' , 'user.USER_ID = logs.USER_ID');

            $queryresult = $this->db->get();

            return $queryresult->result();

        }
    }
?>