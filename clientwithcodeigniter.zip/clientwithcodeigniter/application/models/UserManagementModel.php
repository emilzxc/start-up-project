<?php
    if (!defined('BASEPATH'))
        exit('No direct script access allowed');

    class UserManagementModel extends CI_Model{

        private $_userid;
        private $_fname;
        private $_lname;
        private $_mname;
        private $_email;
        private $_password;
        private $_position;
        private $_permissions;
        private $_createdDate;
        private $_statusid;


        public function setID($userID){
            $userID = setUserID();
            $this->_userid = $userID;
        }

        public function setFname($Fname){
            $this->_fname = $Fname;
        }

        public function setLname($Lname){
            $this->_lname = $Lname;
        }
        
        public function setMname($Mname){
            $this->_mname = $Mname;
        }

        public function setEmail($Email){
            $this->_email = $Email;
        }

        public function setPassword($password){
            $this->_password = password_hash($password , PASSWORD_DEFAULT);
        }

        public function setPosition($position){
            $this->_position = $position;
        }

        public function setPermissions(){
            
        }

        public function setStatus($accountStatus){
            $this->_statusid = $accountStatus;
        }

        // Create User to database with multiple table
        public function addUser(){

            $rawDate = date("Y-m-d h:i");
            $this->_userid = $this->setUserID();

            $this->_createdDate = $rawDate;

            $datauserinfo = array(
                'USER_ID' => $this->_userid,
                'F_NAME' => $this->_fname,
                'M_NAME' => $this->_mname,
                'L_NAME' => $this->_lname,
            );

            $dataemail = array(
                'USER_ID' => $this->_userid,
                'EMAIL_ADDR' => $this->_email,
            );

            $datapassword = array(
                'USER_ID' => $this->_userid,
                'Password' => $this->_password,
                'CRTDN_DT' => $this->_createdDate,
            );

            $dataposition = array(
                'USER_ID' => $this->_userid,
                'USER_ROLE' => $this->_position,
            );

            $dataactive = array(
                'USER_ID' => $this->_userid,
                'STATUS_ID' => $this->_statusid,
            );

            $this->db->insert('tbl_userinfo' , $datauserinfo);
            $this->db->insert('tbl_email', $dataemail);
            $this->db->insert('tbl_password' , $datapassword);
            $this->db->insert('tbl_user_role', $dataposition);
            $this->db->insert('tbl_account_status' , $dataactive);

            return $this->db->insert_id();
        }

        //Set Userid 
        public function setUserID(){
            $this->db->select('*');
            $this->db->from('tbl_userinfo');
            $row_num = $this->db->get()->num_rows();

            $rawuserid = str_replace("-", "", date("Y-m-d"));

            $_userid = $rawuserid . $row_num;

            return $_userid;
        }
    }
?>