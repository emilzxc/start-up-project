-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 08, 2019 at 08:05 AM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `clientdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_account_status`
--

CREATE TABLE `tbl_account_status` (
  `USER_ID` int(11) NOT NULL COMMENT 'User id on tlb_userinfo',
  `STATUS_ID` int(11) NOT NULL COMMENT 'staus_id on tbl_status',
  `DATE_ACTV` datetime NOT NULL COMMENT 'Date account activated'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_account_status`
--

INSERT INTO `tbl_account_status` (`USER_ID`, `STATUS_ID`, `DATE_ACTV`) VALUES
(201911073, 0, '0000-00-00 00:00:00'),
(201911072, 0, '0000-00-00 00:00:00'),
(201911071, 0, '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_email`
--

CREATE TABLE `tbl_email` (
  `EMAIL_ID` int(11) NOT NULL COMMENT 'Email ID',
  `USER_ID` varchar(255) NOT NULL COMMENT 'User id on tlb_userinfo',
  `EMAIL_ADDR` varchar(255) NOT NULL COMMENT 'Email Address'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_email`
--

INSERT INTO `tbl_email` (`EMAIL_ID`, `USER_ID`, `EMAIL_ADDR`) VALUES
(1, '201911070', 'sada@gamil.com'),
(2, '201911071', 'sada@gamil.com'),
(3, '201911072', 'emilio@mbsi.com'),
(4, '201911073', 'emilio@mbsi.com');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_logs`
--

CREATE TABLE `tbl_logs` (
  `LOG_ID` int(11) NOT NULL,
  `LOG_DCR` varchar(255) NOT NULL COMMENT 'user activity while in the system',
  `USER_ID` varchar(225) NOT NULL COMMENT 'user_id on tbl_userinfo',
  `DATE_CRT` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_password`
--

CREATE TABLE `tbl_password` (
  `PASSWORD_ID` int(11) NOT NULL COMMENT 'Password ID',
  `USER_ID` varchar(225) NOT NULL COMMENT 'User id on tlb_userinfo',
  `Password` varchar(255) NOT NULL COMMENT 'Password Hashed',
  `CRTDN_DT` datetime NOT NULL COMMENT 'Date Created',
  `LST_UPDT` datetime NOT NULL COMMENT 'Last Updated'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_password`
--

INSERT INTO `tbl_password` (`PASSWORD_ID`, `USER_ID`, `Password`, `CRTDN_DT`, `LST_UPDT`) VALUES
(1, '201911070', '$2y$10$B1nAVVuo5vx0415mn3N9jO2V0ADISr.jN6OHH4Lv83qVMClDoe3Ja', '2019-11-07 00:00:00', '0000-00-00 00:00:00'),
(2, '201911071', '$2y$10$I04at2bMTeguW5jnh6XF.uKI9XsK.av2Yy3bpwi2KmTfljwMT/u.y', '2019-11-07 00:00:00', '0000-00-00 00:00:00'),
(3, '201911072', '$2y$10$HXq2ysYT6axql9JGS5ZfS.jLSmlpmDlMOoqukpj4l3wSNpasod5TO', '2019-11-07 00:00:00', '0000-00-00 00:00:00'),
(4, '201911073', '$2y$10$lKBQ8WwA1EaAitm0cn1kMeFUXHqBjP7HHSu9KlpmPC.lX1qBJHvqa', '2019-11-07 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_permissions`
--

CREATE TABLE `tbl_permissions` (
  `PER_ID` int(11) NOT NULL COMMENT 'Permissions ID',
  `USER_ID` int(11) NOT NULL COMMENT 'User id on tlb_userinfo',
  `ALLW_RA` int(11) NOT NULL COMMENT 'Allow in Recent Activity ',
  `ALLW_PT` int(11) NOT NULL COMMENT 'Allow in Payroll Table',
  `ALLW_AU` int(11) NOT NULL COMMENT 'Allow to add user',
  `ALLW_PDF` int(11) NOT NULL COMMENT 'Allow to export in PDF',
  `ALLW_EXCEL` int(11) NOT NULL COMMENT 'Allow to export in EXEL'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_role`
--

CREATE TABLE `tbl_role` (
  `ROLE_ID` int(11) NOT NULL COMMENT 'Role ID',
  `USER_ROLE` int(11) NOT NULL COMMENT 'Role Number',
  `ROLE_DESC` varchar(225) NOT NULL COMMENT 'Role Description'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_role`
--

INSERT INTO `tbl_role` (`ROLE_ID`, `USER_ROLE`, `ROLE_DESC`) VALUES
(1, 1, 'Payroll Administrator'),
(2, 2, 'Payroll Associate');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_status`
--

CREATE TABLE `tbl_status` (
  `STATUS_ID` int(11) NOT NULL,
  `STATUS_DESCR` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_status`
--

INSERT INTO `tbl_status` (`STATUS_ID`, `STATUS_DESCR`) VALUES
(0, 'Not Activated'),
(1, 'Activated');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_userinfo`
--

CREATE TABLE `tbl_userinfo` (
  `USER_ID` varchar(255) NOT NULL COMMENT 'USER_ID',
  `F_NAME` varchar(255) NOT NULL COMMENT 'First Name',
  `M_NAME` varchar(255) NOT NULL COMMENT 'Middle Name',
  `L_NAME` varchar(255) NOT NULL COMMENT 'Last Name'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_userinfo`
--

INSERT INTO `tbl_userinfo` (`USER_ID`, `F_NAME`, `M_NAME`, `L_NAME`) VALUES
('201911070', 's', 's', ''),
('201911071', 'sample1', 'Sample2', 'sample'),
('201911072', 'emm', 'emmm', 'em'),
('201911073', 'emm', 'emmm', 'em');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_role`
--

CREATE TABLE `tbl_user_role` (
  `USER_ID` varchar(255) NOT NULL COMMENT 'User id on tbl_userinfo',
  `USER_ROLE` int(11) NOT NULL COMMENT 'Role id in tbl_role'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_user_role`
--

INSERT INTO `tbl_user_role` (`USER_ID`, `USER_ROLE`) VALUES
('201911071', 2),
('201911072', 2),
('201911073', 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_email`
--
ALTER TABLE `tbl_email`
  ADD PRIMARY KEY (`EMAIL_ID`);

--
-- Indexes for table `tbl_logs`
--
ALTER TABLE `tbl_logs`
  ADD PRIMARY KEY (`LOG_ID`);

--
-- Indexes for table `tbl_password`
--
ALTER TABLE `tbl_password`
  ADD PRIMARY KEY (`PASSWORD_ID`);

--
-- Indexes for table `tbl_permissions`
--
ALTER TABLE `tbl_permissions`
  ADD PRIMARY KEY (`PER_ID`);

--
-- Indexes for table `tbl_role`
--
ALTER TABLE `tbl_role`
  ADD PRIMARY KEY (`ROLE_ID`);

--
-- Indexes for table `tbl_status`
--
ALTER TABLE `tbl_status`
  ADD PRIMARY KEY (`STATUS_ID`);

--
-- Indexes for table `tbl_userinfo`
--
ALTER TABLE `tbl_userinfo`
  ADD PRIMARY KEY (`USER_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_email`
--
ALTER TABLE `tbl_email`
  MODIFY `EMAIL_ID` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Email ID', AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_logs`
--
ALTER TABLE `tbl_logs`
  MODIFY `LOG_ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_password`
--
ALTER TABLE `tbl_password`
  MODIFY `PASSWORD_ID` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Password ID', AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_permissions`
--
ALTER TABLE `tbl_permissions`
  MODIFY `PER_ID` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Permissions ID';

--
-- AUTO_INCREMENT for table `tbl_role`
--
ALTER TABLE `tbl_role`
  MODIFY `ROLE_ID` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Role ID', AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
