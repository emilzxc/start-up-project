  $(document).ready(function(){
    $('.sidenav').sidenav();
    $('.dropdown-trigger').dropdown();
    $('.fixed-action-btn').floatingActionButton();
    $('.tap-target').tapTarget();
    $('.tap-target').tapTarget('open');
    $('.modal').modal();
    $('select').formSelect();
  });
        